# NullDynasty video skill (course edition)

A Claude skill that makes map-story Shorts in the NullDynasty style, end to end, plus all the working code behind
three real videos.

## Install

1. Unzip. You get `nulldynasty-video/` (the skill) with `template/` (a working Remotion project), `examples/`,
   `references/` and `skills_bundled/`.
2. Put the skill where Claude Code finds skills:
   - for one project: copy `nulldynasty-video/` to `<your project>/.claude/skills/nulldynasty-video/`;
   - for all your projects: copy it to `~/.claude/skills/nulldynasty-video/`.
   Also copy `skills_bundled/yt-script` and `skills_bundled/yt-seo` next to it (they keep their MIT licence,
   `skills_bundled/YT-SKILLS-LICENSE`).
3. Start your video project from the template: copy everything inside `template/` into your project folder (or use
   `template/` itself), then `npm ci`.
4. Install the Python side: `pip install numpy scipy pillow pyshp shapely scikit-image faster-whisper`, plus ffmpeg.
5. Put your own brand files in `public/brand/` (`Montserrat.ttf` from Google Fonts, your round logo as
   `logo_round_192.png`) and set your handle in `src/brand/Watermark.tsx`.

## Use it

Ask Claude for any step, for example:
- "Here is my reference video, analyse it frame by frame."
- "Write the script for this topic with /yt-script."
- "Give me the image prompts and the Omni prompts for my host."
- "Here are my VO, images and host clips: build the edit."
- "Render the preview", "Render 4K on 2 helpers", "Give me the SEO kit."

The skill (`SKILL.md`) walks Claude through the 12 steps and points it to the right guide in `references/`.

## What you download yourself (free, not redistributable here)

- Satellite tiles (EOX Sentinel-2 cloudless, CC BY 4.0) and terrain (AWS Terrain Tiles): the map tools fetch them.
- Natural Earth 10 m data: one `curl` loop in `references/05_maps.md`.
- Music from Mixkit and sound effects from the Sonniss GDC bundles: file names in `references/09_sound.md`.
- Google Fonts: Anton, Jost, Baloo 2, Montserrat.

## The three example videos inside `template/src/`

- `canadalakes`: Canada's weird lake names (79 s). Start new videos from this one.
- `ukweather`: the house-style reference (UK weather), with 18 motion components.
- `sikkim`: Sikkim's first railway, with Blender shots, rain, storm, gauges and a cloud-wipe loop.

Their scripts, analyses, prompts and upload kits are in `examples/`. Their images, footage, voice and music are the
channel's own and are not included: the code shows exactly where each one goes.
