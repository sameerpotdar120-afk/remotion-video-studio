# 11 · Thumbnail and upload kit

"Upload kit" or "SEO kit" always means: the thumbnail + the text for YouTube and Instagram, delivered together. Use
the bundled `yt-seo` skill for the method. Save as `exports/<topic>_upload_kit.md` and paste it into the chat as
copyable blocks.

## Thumbnail

The Cover composition (`src/<topic>/edit/Cover.tsx`): the video's strongest frame rebuilt as a still, at most 3-4
big words, a red tag, one or two pins. Everything that matters inside the 3:4 crop (y 240-1680) so it works on both
YouTube and Instagram. Render 1080×1920 and `--scale=2` (2160×3840), save as JPG quality 2 (`-q:v 2`):
`exports/<topic>_thumbnail.jpg`, `exports/<topic>_thumbnail_4k.jpg`. Look at it: no overlapping labels, no black
band where a plate ends.

## The kit (format)

```
# <Hindi title>: upload kit
Upload file … (resolution, frames, length, size; LFS link)
Thumbnail …

## Search queries this should win
1. `<english query>` / `<roman hindi query>`
2. …
3. …
(The title and the first two description lines carry the words from all three.)

## YouTube
**Title** (≤ 60 characters visible; Hindi + the English names people type; one emoji)
Backup titles (two)
**Description**
  line 1-2: what the video gives, in the words people search (this is the search snippet)
  "इस Short में:" one line per beat, with an emoji each
  the comment question
  3-5 hashtags
  ---
  credits: every source with its licence, the AI disclosure (illustrations, host, voice), music, SFX
**Tags** (15: spellings, names, the long names people type; no stuffing)
**Settings:** "Altered or synthetic content" = Yes
**Pinned comment** (a one-word-answer question or a guess-the-answer prompt; an answer reply to post later if needed)

## Instagram Reel
**Caption** (hook line, one fact, the comment question, a send-to-a-friend line tied to identity, 8-10 hashtags)
Credits for the first comment
```

Examples: `examples/canadalakes/upload_kit.md`, `examples/sikkim/upload_kit.md`, `examples/ukweather/upload_kit.md`.

End with: "Ship it, or change it?"
