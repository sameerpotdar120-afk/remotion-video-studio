# 02 · Script

Use the bundled `yt-script` skill (`skills_bundled/yt-script`) for the method and its hook scorer:

```bash
python3 skills_bundled/yt-script/hookscore.py hooks.txt      # rank 5 hook options
python3 skills_bundled/yt-script/hookscore.py --hook "one line"
```

Write FIVE hooks (in English, so the scorer can read them), score them, show the creator the top two with their
panels, and say which formula the winner uses. Then the script.

## The voice (NullDynasty; adapt to your own channel)

- Spoken Hindi with natural Hinglish. English nouns stay English when spoken that way. Numbers as digits.
- Open straight on the picture or the claim, often "सोचो, …". No "दोस्तों", no channel intro, no "आज हम बात करेंगे".
- One everyday metaphor carried through; short punchy clauses; "बस …" to land a consequence; "और अब …" to bring it to
  today.
- Dramatic but hedged where the evidence is an estimate or a forecast ("हो सकता है", "करीब").
- Respect for communities: name them with warmth ("हमारे … भाई" for Indian communities; for others, their own name,
  like "First Nations"). Never make a people sound passive, primitive or like a footnote.
- Full, grammatical sentences with natural rhythm. Never clip a sentence to save words: say it whole or cut it.
- Length: 60-90 s (about 2.6 Hindi words per second at a natural pace; 190 words ≈ 75 s).

## What the channel's own data said (Instagram, 8 reels)

- Shares decide reach: the reels past 200K views were shared by 1.4-4.9 % of viewers. Pick topics people send to
  someone: their country, city, language, daily life, or a danger to them.
- Frame 0 = one clear picture + at most 3-4 big words. Openings that started on a sentence or jargon lost 26-32 % in
  the first seconds; picture-first openings lost 17-20 %.
- Pay part of the hook off by 8-10 s. No dates or background before the first payoff; never two dates in a row.
- Comments are rare: try a one-word-answer question, or a send prompt tied to identity.
- Mix the week: about half REACH topics (any topic, a shock that works with zero context) and half CONNECT topics
  (identity, daily life, something worth sending), as many BOTH as possible. Don't force an India angle into a world
  story; add one only where it is real.

## Loop ending (instead of a CTA)

The last line stops mid-sentence so it runs straight into the first line, and the last frame matches frame 0, so
viewers watch again without noticing the end. Line 1 must work both as a cold open and as the end of that last
sentence. Examples: Sikkim ended "… इसीलिए तो…" into "भारत में 7,000 से ज़्यादा रेलवे स्टेशन हैं…"; Canada ended
"तो सोचो, तुम्हें 20 लाख झीलों के नाम रखने हैं…" into its first line. No host at the very end of a loop video.

## Polishing the creator's own draft

When the creator writes the script (often in Roman Hinglish): keep every line theirs, convert to clean Devanagari,
fix grammar, check every fact on the web and change only what is wrong, keep the loop ending, and list each change
with its reason. Split names ElevenLabs will mangle into syllables (e.g. "पेकवाच-नामे-कोस्क-वास्क-वे-पिन-वानिक") while the
screen shows the real spelling.

## Fact check (always)

Search for every number, date and name. Prefer official records (national names databases, government pages) and
encyclopedias; note where sources disagree; say "करीब" for counts that depend on definitions (e.g. "20 लाख झीलें,
छोटी-बड़ी मिलाकर" when ~880,000 lakes are over 10 ha and "over two million" counts tiny ones). Drop what you cannot
confirm (the Canada reference's "This Lake" had no official record, so it was cut). List the sources at the end of
the hand-over.

## Hand-over format

- the two best hooks with their scored panels and the formula of the winner;
- the script beat by beat, each beat with `[ON SCREEN: …]`;
- the runtime estimate;
- fact-check notes and sources;
- the final script in one copyable block for ElevenLabs;
- last line: "Ship it, or change it?"

Examples: `examples/canadalakes/script_hindi.txt`, `examples/sikkim/script_hindi.txt`, `examples/ukweather/`.
