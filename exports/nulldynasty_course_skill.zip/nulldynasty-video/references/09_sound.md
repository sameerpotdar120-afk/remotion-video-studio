# 09 · Sound: VO, music bed, SFX, loop-safe mix

Template: `tools/mix_canadalakes.py` (the UK weather and Sikkim mixes are there too). Copy it to
`tools/mix_<topic>.py`, point `AUD`/`T` at the topic, pick the music, write the cue list, run:

```bash
cd tools && python3 mix_<topic>.py      # writes public/<topic>/audio/mix.wav
```

## Sources (download yourself; they may not be redistributed)

- Music: Mixkit (free licence, mixkit.co). Name files `music_<name>_mixkit.mp3`. Tracks we used: "Kidding Around"
  (playful, Canada), "Silent Descent" (dark, pulsing, Sikkim), "Epical Drums 02/06" (tense sections), "Discover",
  "Summer Fun", "Possible Dreams", "Vastness".
- SFX: Sonniss GDC Game Audio Bundles (royalty-free). Save as `public/<topic>/audio/sfx/<name>.mp3`. The Canada mix
  uses: `pop_light pop_hard pop_high wh_fast swoosh_fast whoosh_transition_fast whoosh_sparkle wh_air_smooth
  wh_magic_air wh_big_tonal typewriter_click cartoon_pops boing dizzy counter_ticking splash drum_hit_big
  bass_hit_short` (pick similar sounds from the bundles and name them so).
- Never use music or sounds from the reference video.

Match the bed to the topic's mood: playful for funny facts, dark and pulsing for danger and engineering, drums for a
tense section.

## How the mix works

1. Voice: the creator's VO through `VOICE_CHAIN` (high-pass 80 Hz, -2 dB at 280 Hz, +2.5 dB at 3.8 kHz, compressor
   3:1, limiter). Its level is the reference for everything else.
2. Music: extended if shorter than the video (its opening crossfaded back in at `EXTEND_AT`), the tail past the end
   equal-power crossfaded into the head (`LOOP_XF`) so the loop has no seam; set to the voice's RMS, then
   sidechain-ducked by a speech envelope: `MUSIC_TALK` dB under while talking (-14 to -21), `MUSIC_PAUSE` in pauses
   (-7 to -11). Short dips under the biggest hits.
3. SFX: `CUES = [(time, name, level_dB, {opts})]`. Each effect is levelled to `voice + level` at its loudest 50 ms;
   by default its peak lands exactly on `time` (a whoosh's centre, an impact's hit), `align: "start"` starts it at
   `time`, `dur` trims it with fades. SFX are ducked 4 dB under the voice. Anything that rings past the end wraps
   round to the start (`place()`), because the video loops.
4. Master: compressor 2:1 and loudness-normalised to -14 LUFS, true peak -1 dB.

## Where the effects go (one on every visual hit)

| On screen | Sound |
| --- | --- |
| camera whip / dive | `whoosh_transition_fast`, `wh_fast`; a big tonal whoosh before a dive |
| fill lands, pin drops, label pops | `pop_hard`, `pop_high`, `pop_light` |
| many things popping (dots, crowd, pins) | a run of `pop_light` 30-120 ms apart, quiet (-20 to -26 dB) |
| counter running | `counter_ticking` with `dur` |
| typed text | one `typewriter_click` per character, timed with the typing |
| kinetic slam / stamp | `bass_hit_short` or `drum_hit_big` + a comic `boing` for a joke |
| card / panel whips | `swoosh_fast` |
| thought bubble | `pop_light` + `dizzy` |
| splash, magic sparkle | `splash`, `whoosh_sparkle`, `wh_magic_air` |

All cue times are written as `C["cue"] ± offset` from `timing.json`, so they move with the edit.

## Check it

The script prints the voice level, the music level while talking and in pauses, and the loudest SFX vs the voice.
Listen to the start and the end together (the loop seam), and to every hit in the preview.
