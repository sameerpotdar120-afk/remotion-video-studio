# 06 · The edit (Remotion)

The template is `template/src/canadalakes/edit/`. A video is one React component driven by time `t` (seconds, at 60
fps), not a stack of clips. Everything on screen is a function of `t`, so any frame renders on its own (that is what
lets helpers render chunks in parallel and what makes the loop exact).

## Composition

`render.tsx` registers `<Topic>4K60` (1080×1920, 60 fps, `durationInFrames = round(DURATION_S·60)`, props
`{ captions: true, audio: '' }`) and `<Topic>Cover` (one frame). Render at `--scale=2` for 2160×3840.

## Layer order (bottom → top)

```
MapLayers(c)          satellite plates under the camera                         Map.tsx
Vectors(t, c)         country fill (white flash → red), lake dots, province fills, lake fills   SVG
Grade                 dark top/bottom gradient + vignette (no grain)
MapOverlays(t, c)     counts, kinetic slams, pins + two-tone labels, typed meanings, stamps, the trout
motion components     QuestionStorm, ThoughtBubble, PeopleCrowd in <At t0 t1> sequences
full-screen inserts   LouiseCard (whip card), MapRoom (cartoon + map on a board), Panels, CatDesk
host split            NullPanel: bottom half, the map shifted up 480 px while it shows
Captions, credits, Watermark, <Audio mix.wav>
```

The map group is wrapped in `translate(shake)` and the camera motion blur: `blur = min(14, speed·0.06 + zoom·6)`
pixels, computed from `camAt(t-1/60)` vs `camAt(t)`.

## The camera (`cam.ts`)

- Coordinates: Web Mercator metres (`merc(lon, lat)`); camera = screen-centre `x, y` + `mpp` (metres per screen
  pixel). `toS(c, p)` maps a point to the screen; `ringsD(c, rings)` makes an SVG path.
- Keys: `{ t, at, mpp, e }` placed on VO cues (`C.<cue>`). Zoom interpolates in log space; on big zooms the position
  follows the zoom so the target stays put on screen (the dive feels like a dive, not a slide).
- Smoothing: each frame averages 7 samples ±0.12 s (a soft camera), then adds:
  - breathe: `1 + 0.022·sin(t·LOOPF(13)) + 0.008·sin(t·LOOPF(31)+1.3)`;
  - drift: `mpp·7·sin(t·LOOPF(19))` in x and `LOOPF(16)` in y;
  - punches on HITS: `0.05·e^(-7Δt)·cos(9Δt)` zoom kicks;
  - shake on the big slams (`kick`).
- `LOOPF(k) = 2πk / DURATION_S`: every periodic motion makes whole cycles over the video, so the last frame equals
  frame 0. The final key returns to `CAM0` exactly at `DURATION_S`.

Typical scales: a whole country ≈ 9,000-10,500 m/px; a province ≈ 2,000-2,600; a big lake ≈ 500; the Shield's small
lakes ≈ 16-19; a 500 m lake ≈ 1.2-2.

## Fills and highlights

- Country (the reference's opening): white at 85 % for ~0.25 s, then red fades in over 0.55 s; white sheen gradient on
  top; 2.5 px white edge. Dims while zoomed in and during the dots.
- Regions (provinces): fill 85 %, sheen, white edge + a blurred glow edge, a soft offset shadow, a springy lift (0.9 →
  1.0 scale) on landing, in and out over 0.3 s.
- Lakes: cyan at 62 %, white edge + glow, growing in over 0.5 s (black for a joke lake).
- Dots ("+20 लाख झीलें"): thousands of small cyan circles from `geo.dots`, switched on in a quick ripple and twinkling.

## Pins and labels

`Pin`: falls 260 px in 0.12 s (ease-in), squash-and-stretch landing (`1 - 0.22·e^(-18Δt)·cos(38Δt)`), a white ring
ripples out from the tip over 0.35 s, the label springs up 0.15 s later. `side={-1}` puts the label on the left when
the pin is near the right edge. `TwoTone`: Anton, a white word and a gold word, thick dark stroke, drop shadow.

Check every label at the screen edges and in the split-screen top half (the map shifts up 480 px): move the camera
target, not the label, when one gets cut.

## Kinetic text

- `Slam`: flies in from the top left at 3.2× and springs down to 1× with a tilt (the reference's "nightmare…").
- Stamps (`OFFICIAL`, `1953`): 2.2-2.4× → 1× with a fast spring, rotated -5°, red border on white.
- `TypeText`: one grapheme every N seconds with a caret; pace it so the typing ends with the spoken word.
- Counter: `toLocaleString('en-IN')` gives Indian grouping (20,00,000).

## Full-screen inserts

- Whip card (`LouiseCard`, `WhipCard`): enters from the right in 5-6 frames with ~34 px blur, settles tilted 2°, slow
  push; leaves left the same way. The card can hold its own mini map (`MapLayers` with its own camera).
- Cartoon room (`MapRoom`): a keyed background with a green board → a map with the same `Vectors` behind it;
  characters spring up from below, staggered 0.2 s, with a small shake.
- Panels: three landscapes stack in from alternating sides, each with a big two-tone label.
- Cat on the keyboard (`CatDesk`): the CRT's green screen shows the map; the cat (body + separate tail) walks across
  with a step bob, the tail swings from its base.

Inserts cover the map, so the map underneath keeps moving (it is still there when the insert leaves).

## The host split

`NULL_WIN` lists `{ name, t0, t1, from }` per clip. During a window the map slides up 480 px and the host panel rises
into the bottom half (0.2 s ease), with a white top border and an "AI-generated host" label. `from` = where the
wanted gesture starts inside the clip.

## Captions

Small (Baloo 2 700, 46 px), white with a dark shadow, y≈1240, three words at a time, each word appearing on its time.
Hidden while the host is on screen and on the first and last 0.3 s (so frame 0 and the last frame match).

## Credits and labels on screen

A tiny credit line at the bottom on every map shot: "Sentinel-2 cloudless 2024 by EOX (CC BY 4.0) · relief: AWS
Terrain Tiles · borders, lakes: Natural Earth · …". Hidden during full-screen inserts. Keep the AI label on the host.

## The thumbnail (`Cover.tsx`)

The video's strongest frame, rebuilt as a still: the map + fills at a chosen `t`, one or two pins, and a hook of at
most 3-4 big words (Anton + Baloo 2, thick strokes) with a red tag. Everything that matters inside the 3:4 crop
(y 240-1680). Render 1080 and `--scale=2` (4K).

## Checking the edit

Render stills across the whole timeline (every beat, both sides of every transition, every label) and look at them
as contact sheets; fix, re-render the changed ones. See `references/10_render.md`.
