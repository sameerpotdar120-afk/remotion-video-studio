# 08 · Blender shots (optional)

Use Blender when a beat needs something a flat map cannot show and the reference cuts to footage: flying up a real
valley, a hill turning see-through to show a tunnel inside, a station at dusk, a train out of a portal. Every shot is
built from code (`tools/blender/*.py`, Blender 4.5 LTS, Cycles on CPU, headless), timed to its VO line, and rendered on
helpers. Code in `template/tools/blender/` is the Sikkim video's (five shots).

Rule from the creator: **every Blender shot must match its VO line** (show exactly what the words say), and **objects
must be big in the frame**: a reel is tall and small; frame the hero so it fills the screen (low, close camera, long
lens for compression), never a tiny prop in a wide landscape.

## Sources (free)

- Terrain: AWS Terrain Tiles + EOX Sentinel-2 (the same sources as the maps). `prep_teesta.py` cuts the valley from the
  video's own terrain and satellite plates into `data/teesta_h.npy` (heights, upsampled 3× bicubic), `teesta_tex.jpg`
  and `teesta.json` (bounds, metres per pixel, the route in local metres from the crop centre).
- Textures and trees: Poly Haven (CC0; credited anyway): `fetch_textures.sh /opt/phx` downloads rock and soil
  textures (2k diff/nor/rough) and a broadleaf tree model.

## The files

| File | What it is |
| --- | --- |
| `sikkim_landslide.py` | the base world: terrain with river, road bench and scar; forest by geometry nodes limited to the camera's view box; box-projected CC0 materials; rocks; rigid-body rockfall exported to JSON so every helper replays it identically; dust as volume puffs; backdrop, clouds, world, camera; aerial haze in the shaders |
| `teesta_world.py` | the real gorge from the DEM (8.4 m grid), satellite colour far, CC0 detail near, water ribbon along the traced river bed, the full DEM sunk under the crop as the surroundings |
| `tunnel7.py` | a tunnel portal on a rail bench and a protection wall of block rigid bodies released on the VO word, a timed slide, wet overcast grade |
| `shots.py` | the five shots with their camera keys on VO times: `--shot gorge|xray|bore|station|train` |
| `render_frames.py` | render a frame range (persistent data, `[samples] [percent] [step]`) to PNG |
| `helper_shot.sh SHOT FIRST LAST STEP SPP` | one helper: install Blender, fetch textures, build the shot, render every STEP-th frame from FIRST |
| `helper_render.sh`, `helper_tunnel7.sh` | the same for the landslide and Tunnel 7 shots |
| `landslide_plate.py` | a 2.5D alternative (the landslide as a plate for Remotion) |

## Making a shot match the line

1. Write the shot as a sentence next to its VO line and time (see the header of `shots.py`).
2. Key the camera on frames from the VO (`F(t)` = frame at 30 fps from the line's start); 30 fps is enough for
   Blender plates, the edit runs at 60 and plays them with `OffthreadVideo`.
3. Time events to words (the wall falls on "गिर गई"; lights come on one by one on "शुरू हो सकता है").
4. Render a few test frames at low samples and look before sending it to helpers.

## Costs we learned

- EEVEE is too slow headless here; Cycles CPU at 20-24 samples with denoise is the sweet spot.
- Limit the forest to the camera's view (`FOREST_BOX`, `TREE_GAP`, `TREE_SCALE`); haze in the shaders, not as a
  volume (`emission_sampling='NONE'`); dust puffs with `visible_shadow=False`.
- Booleans that empty a mesh: use separate manifold cutters.
- Rigid bodies sliding or falling through: offsets, a catch floor, kinematic until the release frame.

## Rendering on helpers (interleaved frames)

Give each helper every N-th frame (`FIRST = k`, `STEP = N`), so all helpers finish together and a slow one leaves
evenly spaced gaps instead of a missing block. Each helper commits its PNGs to its own branch; pull them, check all
frames exist (PNG > 100 KB, re-fetch smaller ones), then:

```bash
ffmpeg -framerate 30 -start_number 1 -i frames/<shot>/f_%04d.png -c:v libx264 -crf 15 -pix_fmt yuv420p \
  -movflags +faststart public/<topic>/blender/<shot>.mp4
```

A frame a helper never rendered (helpers' background commands stop at 2 hours): blend its two neighbours 50/50 (at
30 fps one blended frame is invisible) and say so in the commit. If a batch will not finish in time, start backup
helpers on the tail of the slow batches; whichever copy arrives first is used.

In the edit, a `BClip` plays `public/<topic>/blender/<shot>.mp4` with `OffthreadVideo` from the shot's VO time and
freezes on its last frame; rain or other overlays are composited on top in Remotion (`Tunnel7Rain`).
