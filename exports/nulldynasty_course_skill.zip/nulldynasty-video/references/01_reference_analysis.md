# 01 · Reference analysis (frame by frame)

The creator picks a reference Short. Our video follows its scene order and the kinds of moves and transitions it
uses, beat for beat, but every picture, map, prop and sound is rebuilt from free sources and our own code. Never
re-use anything from the reference itself.

## 1. Measure the file

```bash
ffprobe -v error -show_entries stream=codec_type,width,height,r_frame_rate,nb_frames:format=duration -of csv=p=0 ref.mp4
```

## 2. Transcribe it (English or Hindi) with word times

```bash
ffmpeg -i ref.mp4 -ac 1 -ar 16000 a.wav
python3 - <<'EOF'
import wave, numpy as np
from faster_whisper import WhisperModel
w = wave.open("a.wav"); a = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
m = WhisperModel("small.en", device="cpu", compute_type="int8")   # "small" for Hindi
for s in m.transcribe(a, word_timestamps=True)[0]:
    print(f"[{s.start:6.2f}-{s.end:6.2f}] {s.text.strip()}")
EOF
```

Keep the transcript for your own analysis only. It is the reference creator's text and is never shipped or reused.

## 3. Find the cuts

```bash
ffmpeg -i ref.mp4 -map 0:v:0 -vf "scdet=threshold=8,metadata=print:file=cuts.txt" -f null -
grep -o "lavfi.scd.time=[0-9.]*" cuts.txt
```

Few hard cuts means the reference is one continuous map camera with whips and slides (most map Shorts are).

## 4. Contact sheets (the whole video, then the micro-frames)

```bash
# every 0.5 s, 36 thumbnails per sheet, timecode burnt in
for i in 0 1 2 3; do ffmpeg -ss $((i*17)) -t 17 -i ref.mp4 -map 0:v:0 \
  -vf "fps=2,scale=180:-1,drawtext=text='%{pts\:hms}':x=4:y=4:fontsize=14:fontcolor=yellow:box=1:boxcolor=black,tile=9x4" \
  -frames:v 1 sheet$i.jpg; done
# frame by frame through one move (here 27.0–28.6 s), frame time burnt in
ffmpeg -ss 27.0 -t 1.6 -i ref.mp4 -map 0:v:0 \
  -vf "scale=150:-1,drawtext=text='%{pts\:flt}':x=4:y=4:fontsize=14:fontcolor=yellow:box=1:boxcolor=black,tile=12x4" \
  -frames:v 1 whip.jpg
```

Look at the sheets, then go frame by frame through every distinctive move: the opening (frames 0-47), each
transition, each label entrance, each kinetic word. Write down durations in frames (at the reference's fps) and
convert to seconds; our edit runs at 60 fps.

## 5. Write `reference_analysis.md`

A table, one row per beat: time range · what is on screen · the motion, frame by frame. Then two short sections:

- **Style notes for our version**: which parts we rebuild how (satellite + fills + pins; whips with blur; kinetic
  slams; cartoon inserts as GPT images; photos as GPT landscapes or Blender renders; app-style maps drawn from open
  data), and which parts of the reference are someone else's and must not be copied.
- **Facts checked**: every claim the reference makes, checked on the web, with what is right, what is only an
  estimate (and how to say it), and what to leave out because no source confirms it.

See `examples/canadalakes/reference_analysis.md` for a complete one (with the opening measured frame by frame: frame
0-11 satellite push, 11-20 fast zoom-out with blur, 21-25 white fill pop, 26-40 label types on while the fill turns
red over ~0.5 s; whips of 4-5 frames with heavy blur).

## What to measure (the checklist)

- Frame 0: a picture or text? (Ours: always a picture, at most 3-4 big words, no Null.)
- Camera: continuous or cut? Zoom speed on the whips (frames), easing.
- Fills: how they appear (flash white then colour; grow from centre), edge glow, sheen.
- Pins and labels: drop, squash, ripple; label style (two-tone? boxed?); when they leave.
- Kinetic text: slam size, overshoot, how long it holds.
- Inserts: cartoon or photo cards, how they enter (whip, slide, stack) and leave.
- Captions: size, position (the reference's were small, ~65 % down), word by word or phrase.
- Music mood and where it changes; SFX on which hits.
- The ending: CTA or loop? (Ours: a loop that runs into frame 0.)
