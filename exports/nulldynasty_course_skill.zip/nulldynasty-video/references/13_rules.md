# 13 · Rules that never bend

## Copyright-free sources only

Never use anything copyrighted by someone else: no Google Earth or Google Maps imagery, no Flightradar24 (or any
app's) screenshots, data or logos, no clips, music, images or text from the reference video, no article screenshots
(rebuild them as your own fact card in your own words). Only:

- EOX Sentinel-2 cloudless (CC BY 4.0, credited on screen)
- AWS Terrain Tiles / SRTM (open data, credited)
- Natural Earth (public domain; the India point-of-view edition for borders)
- Mixkit music (free licence) and Sonniss GDC sound effects (royalty-free)
- Google Fonts (OFL)
- Poly Haven (CC0) textures and models for Blender
- the creator's own images (GPT / Gemini) and host clips (Omni)
- graphics drawn in code

Credit every source that asks for it, on screen and in the description.

## India's map

Whenever India appears in any layer, it is the official boundary (all of J&K including PoK and Gilgit-Baltistan,
Ladakh including Aksai Chin and Shaksgam, all of Arunachal Pradesh), point-tested before rendering. See 05_maps.md.

## AI disclosure

Set "Altered or synthetic content" to Yes on YouTube; say in the description which parts are AI (illustrations, host,
voice); keep the "AI-generated host" label on screen while the host shows.

## Facts

Never invent a number, a result, a source or a quote. Check every claim; hedge estimates; drop what cannot be
confirmed.

## People and communities

Speak about every community with warmth and respect. Show what was done to people, not what they "became". Local
facts the creator knows first-hand are stated plainly.

## The host

Your own host character only (never someone else's). Middle of the video only, in split screen, 5-8 s per Short.
Never on frame 0, never at the end of a loop video.

## The creator's word wins

Scripts, titles and edits are proposals until the creator says "ship it".

## Never

- grain;
- an obvious CTA at the end of a loop video;
- Veo or other AI footage unless the creator asks (the channel switched to code-built motion and Blender);
- paid generation services without the creator's OK.
