# 00 · Setup (once per machine)

## Install

```bash
# Node 22 (Remotion 4 needs ≥18; 22 is what we use), ffmpeg 6+, Python 3.11+
cd template && npm ci                      # remotion 4.0.523, react 19, three (for 3D tests)
pip install numpy scipy pillow pyshp shapely scikit-image faster-whisper
# optional: Blender 4.5 LTS for 3D shots (tools/blender/helper_shot.sh downloads it on a helper)
```

Headless Chrome: Remotion downloads its own, or point it at an installed one with `--browser-executable=<path>`
(cloud containers usually have one under `/opt/pw-browsers/chromium_headless_shell-*/chrome-linux/headless_shell`).

## Project layout for each video (topic = a short id like `canadalakes`)

```
public/<topic>/
  script_hindi.txt  reference_analysis.md  asset_prompts.md  omni_prompts.md  motion_assets.md
  img/      cut-out images (PNG with alpha) and landscapes (JPG)
  maps/     <plate>_geo.jpg satellite plates
  fonts/    Anton.ttf, Jost.ttf, Baloo2.ttf (Google Fonts, OFL)
  null/     host clips (rename for your host), muted
  audio/    vo.mp3, music_<name>_mixkit.mp3, sfx/*.mp3, mix.wav
public/brand/   Montserrat.ttf, logo_round_192.png (YOUR logo)
src/<topic>/    geo.json, edit/*, motion/*
tools/          build_<topic>_maps.py, mix_<topic>.py
exports/        <topic>_4k60_master.mp4 (Git LFS), <topic>_thumbnail(_4k).jpg, <topic>_upload_kit.md
```

## Fonts (all Google Fonts, OFL)

- Anton: big condensed labels and numbers (`TITLE`).
- Jost: small labels and credits (`LABEL`).
- Baloo 2: Hindi text, captions and Hindi labels (`UI`).
- Montserrat: the watermark handle.

Download them from fonts.google.com into `public/<topic>/fonts/` and `public/brand/`.

## Git

- Big outputs (the 4K master) go through Git LFS: `git lfs track exports/<topic>_4k60_master.mp4`.
- In a cloud session with little disk, keep finished topics out of the working copy with
  `git sparse-checkout set <only what you need>`; everything stays on GitHub.
- When pushing normal commits from a machine that has no LFS objects locally, `GIT_LFS_SKIP_PUSH=1 git push` avoids
  re-uploading.

## A minimal public dir for renders

Renders only need the topic's files and the brand files. Make a folder with two symlinks and pass it as
`--public-dir`, so the bundler does not copy the whole `public/` tree every time:

```bash
mkdir -p /tmp/pub && ln -sfn $PWD/public/<topic> /tmp/pub/<topic> && ln -sfn $PWD/public/brand /tmp/pub/brand
```
