# 03 · Prompts: images and host clips

When the script is shipped and the creator asks for prompts, deliver together: (1) image prompts, (2) host-clip
prompts, (3) the motion components (step 7) as tested code. Maps are never generated: they come from satellite data
(step 5).

## When to ask for images at all

Code draws the maps, fills, pins, labels, icons, crowds, bubbles, stamps, routes, gauges, weather and most props.
Ask for images only where the reference cuts to something code cannot draw well: cartoon characters (cartographers,
a cat), photo-like landscapes, a hero prop. Keep the count low (10 is plenty) and reuse one image several times.

## Image prompt file format (the creator's rule)

Only the prompts and the style. No beat maps, checklists or explanations. One line of style + size at the top, then
for each image its file name and one self-contained, paste-ready prompt (JSON style: subject, look, pose, style,
framing, background, size, avoid).

Rules that matter:
- **Big subjects.** "The subject fills 85-90 % of the frame, nothing cut off." Small props look cheap in a reel.
- **Cut-out backgrounds.** Plain pure white #FFFFFF, no floor, no shadow (shadows are added in code). For a screen or
  a board that will show a map or video, a flat solid pure green #00FF00 rectangle.
- **Parts for anything that moves.** One image per moving part, same camera, angle, scale and light (a cat body
  without a tail + the tail alone; a door + the frame with the hole filled). Each part has its own full prompt.
- **No text, no logos, no watermark** in any image; words are drawn in code.
- **4K**: 9:16 for characters and backgrounds, 16:9 for landscape panels and side-on props.
- **Style**: say it in every prompt. For cartoons: "2D flat cartoon, clean vector shapes, soft cel shading, thin dark
  outlines, warm muted colours, like an animated explainer". For landscapes: "photoreal, natural colours, sharp
  detail, no grain".
- **Real people**: tell the tool to base the likeness on a free reference photo (public domain, Wikimedia Commons,
  official government photo), never to copy a copyrighted photo.

See `examples/canadalakes/asset_prompts.md` (10 prompts: cat + tail, CRT desk with a green screen, two
cartographers, a map room with a green board, a trout on a hook, three landscapes).

## Your host character (NullDynasty's is "Null")

Make your own recurring host once: a distinctive look that reads at thumbnail size, made in an image tool, plus one
fixed seated studio master image (9:16). The host never speaks on camera (no lip-sync); the VO plays over hand
gestures. Disclose the host as AI.

Screen-time rules:
- Middle of the video only, in split screen (video in the top half, host in the bottom half). Never at the start
  (frame 0 is pictures only) and never at the very end of a loop video.
- 5-8 s in total in a Short under ~70 s; 10-15 s split over 2-3 moments in a ~2-minute video.

## Host clip prompts (Google Omni, 10 s, 9:16)

For each clip: the file name, the script line it belongs to, a main prompt and a short backup prompt. Attach the
studio master image as the starting frame.

```
Animate this stylised 3D animated character as a friendly podcast host in his studio. Keep the image, character
design, studio, microphone, lighting and framing exactly as they are, with a static camera.

He explains "<the idea of the line>":
0–3 s: <gesture 1>.
3–5 s: <gesture 2>.
5–7 s: <gesture 3>.
7–10 s: he rests both hands calmly on the desk.

Smooth, calm, explanatory movements, with his hands near the microphone. His face design stays the same throughout.
No dialogue, no text.
```

Omni's safety filter over-blocks. Describe the host as a stylised 3D animated podcast host in a costume mask; never
write "masked man", "mysterious", "hidden", "hood up", "gloves", "glowing eyes" or anything that reads as a threat.
Keep prompts short and positive (few "never/no" lines), gestures friendly and explanatory, and let the attached image
carry the look.

Good gestures: counting on fingers, a shrug with palms up, scratching the head, a playful facepalm, pinching a tiny
gap then opening hands wide, rain fingers, a hand sliding down a tilted hand (a slope), tapping the desk once.

Examples: `examples/canadalakes/omni_prompts.md`, `examples/sikkim/omni_prompts.md`.

When clips come back: mute them, and crop the split-screen band so the generator's corner sparkle (bottom right of
the 1080×1920 frame, around x 864-935, y 1704-1775) is outside it. Keep the "AI-generated host" label on screen.
