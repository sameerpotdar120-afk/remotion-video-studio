# 04 · Ingest: images, host clips, VO timing

Check every file the creator sends before using it:

```bash
unzip -l assets.zip                                  # what is inside (extract into its own empty folder)
python3 -I -c "from PIL import Image; im=Image.open('x.png'); print(im.size, im.mode)"
ffprobe -v error -show_entries stream=codec_type,width,height,r_frame_rate:format=duration -of csv=p=0 clip.mp4
```

Make a contact sheet of all the images and look at it; then a filmstrip of each host clip (`fps=1,tile=10x1`) to see
which gesture is where.

## Cut-outs (white background → alpha)

```bash
python3 -I tools/cutout_white.py in.png public/<topic>/img/c01_cat.png
```

Near-white pixels connected to the image border are background, so white parts inside the subject (a shirt, a
belly) survive. Edge eroded 1 px, feathered, cropped to the subject. Check every cut-out on a strong colour (red) to
spot halos.

## Green screens (a monitor, a map board)

```bash
python3 -I tools/greenkey.py c03_crt_desk.png public/<topic>/img/c03_crt_desk.png
# prints: screen box x0 y0 x1 y1  → place the map layer behind that box (scale coordinates to 1080 wide)
```

## Landscapes

Save as JPG quality 92 (`img/l01_long_lake.jpg`); 16:9 panels are shown with `objectFit: cover`.

## Host clips

```bash
ffmpeg -i clip.mp4 -an -c:v copy public/<topic>/null/null_<topic>_A1.mp4    # mute, keep the video untouched
```

The edit shows the clip in a 1080×960 band starting at y≈470 of the 1920 frame (the mask and hands), scaled 1.12-1.16
with a slow push. `startFrom` picks the gesture inside the 10 s clip.

## VO word timing

```bash
python3 tools/vo_timing.py public/<topic>/audio/vo.mp3 public/<topic>/script_hindi.txt /tmp/vo
```

It prints the segments, every word with its start time, and the pauses. Whisper's Hindi spelling is rough and it can
merge a long stretch into one segment with no word times: use the printed pauses to split that stretch (each pause is a
phrase boundary; count the phrases against the script).

Then pick one cue per beat (the word where the picture should change) and write `cues.json`, plus the script lines
with their start and end times in `lines.json`, and build the timing file:

```bash
python3 tools/make_timing.py cues.json lines.json src/<topic>/edit/timing.json 78.95
```

Cue names are short ids: `<word><line>` (e.g. `bees1`, `another7`, `y1953`). Every camera key, fill, pin, label and
SFX refers to these names, so retiming a line means changing one number.

Captions come from the creator's own script text, spread over each line by character length (never from Whisper's
spelling).

## The VO itself

The creator records or generates it (ElevenLabs) from the final script. Copy it to `public/<topic>/audio/vo.mp3`. The
video's length is the VO's length (plus a hair); the VO starts on frame 0 with no lead-in silence in a loop video.
