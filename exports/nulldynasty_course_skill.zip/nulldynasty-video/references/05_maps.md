# 05 · Maps: plates and geo data (free sources only)

Never use Google Maps / Google Earth / app screenshots. Everything comes from:

| Source | What | Licence | Credit |
| --- | --- | --- | --- |
| EOX Sentinel-2 cloudless 2024 | satellite tiles, `https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2024_3857/default/g/{z}/{y}/{x}.jpg` (z0-16; native detail ≈ z14) | CC BY 4.0 | "Sentinel-2 cloudless 2024 by EOX (CC BY 4.0)" on screen and in the description |
| AWS Terrain Tiles (terrarium) | elevation, `https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png` | open data (SRTM/NASA, ETOPO1/NOAA) | "relief: AWS Terrain Tiles" |
| Natural Earth 10 m | countries (`ne_10m_admin_0_countries_ind` = **India point-of-view edition**), provinces (`ne_10m_admin_1_states_provinces_lakes`), lakes (`ne_10m_lakes`), rivers | public domain | "borders: Natural Earth" |

```bash
mkdir -p ne && cd ne
for u in cultural/ne_10m_admin_0_countries_ind physical/ne_10m_lakes cultural/ne_10m_admin_1_states_provinces_lakes; do
  curl -sSfL -o x.zip https://naciscdn.org/naturalearth/10m/$u.zip && unzip -o -q x.zip && rm x.zip; done
```

## The builder

`tools/build_canadalakes_maps.py <tile_cache> <ne_dir> [plate names]` is the template. Copy it to
`tools/build_<topic>_maps.py` and edit three lists:

```python
PLATES = [  # name, satellite zoom, dem zoom, lon0, lon1, lat0, lat1
    ("namerica", 5, 4, -172.0, -10.0, 14.0, 83.5),   # overview
    ("canada", 6, 5, -142.0, -50.0, 41.0, 72.0),      # the country
    ("shield", 13, 9, -93.78, -93.30, 53.93, 54.13),  # a close-up
    ...
]
NAMED = {"Lake Louise": (-116.2195, 51.4160, "louise"), ...}   # small features traced from the satellite
PROVINCES = ["British Columbia", "Manitoba", "Nova Scotia", ...]
```

It writes `public/<topic>/maps/<name>_geo.jpg` and `src/<topic>/geo.json` with:
`plates` (Mercator bounds + pixel size), `countries`, `provinces`, `lakes` (rings in Web Mercator metres), `points`
(named places) and `dots` (water pixels inside the country, for the "+N lakes" light-up). Plates bigger than 8192 px
are scaled down (CAP).

Two plate styles:
- Overview plates (`uk.build(..., sat_water=True)`, from `build_ukweather_maps.py`): satellite + multi-directional
  hillshade soft-lit onto land; the sea replaced by a depth tint (turquoise shelf → navy abyss) with seabed relief;
  teal/warm grade, vibrance, unsharp mask.
- Close-up plates (`closeup()`): the satellite as it is with a soft relief and the grade. Use these for anything
  zoomed in on land: the DEM water tint paints blocky blue squares over small dark lakes.

## Size every close-up for a vertical frame

A 9:16 frame at camera scale `mpp` (metres per screen pixel) shows 1080·mpp × 1920·mpp metres. A plate must be at
least that big (×1.2) at the closest zoom you use it at, in Mercator metres (Mercator stretches north-south by
1/cos(latitude)):

```
lat span (degrees) ≥ 1920 · mpp_min · 1.2 · cos(lat) / 111320
lon span (degrees) ≥ 1080 · mpp_min · 1.2 / 111320
```

Pick the satellite zoom so the plate's native metres-per-pixel is close to `mpp_min` (z14 ≈ 9.5 m/px at 0°, z16 ≈ 2.4
m/px); going finer than z14 only upsamples Sentinel's 10 m pixels.

## Features that are not in Natural Earth (small lakes, islands, reservoirs)

`trace()` outlines them from the satellite itself, so the outline is exactly what the viewer sees:
- Default: water = dark and not green (`lum < 0.24 and b ≥ g - 0.006`) or glacial turquoise; the biggest water patch
  touching a 60 px disc round the published point wins.
- Dark lakes in dark forest: region growing from the darkest pixel near the seed (`TOL = {name: 0.03}`, skimage
  `flood` with that tolerance).
- Lakes joined to neighbours by rivers: clip to a box (`CLIP = {name: (lon0, lon1, lat0, lat1)}`) and open the mask.

Always check: draw every traced outline in red on its plate with a yellow circle at the published point, make one
contact sheet, and compare sizes with a published length or area (e.g. the long-name lake traced at 8.6 km against a
published 8.9 km). Published points can sit on an island or the shore, and some come from a second record that says
"southwest of …": move the seed onto the right lake.

## India, always official (never miss this)

Whenever India is on screen in any layer, it is the official map: all of Jammu & Kashmir including PoK and
Gilgit-Baltistan, Ladakh including Aksai Chin and the Shaksgam valley, and all of Arunachal Pradesh. Use Natural
Earth's India point-of-view countries file, never a dataset drawn on de facto lines (Natural Earth's time-zone
polygons, for example, put PoK and Aksai Chin outside India: cut India out of every such layer and add it whole).
Before rendering, point-test the India polygon with shapely at Gilgit, Muzaffarabad, Aksai Chin, Shaksgam and Tawang
(all must be inside), and do not cover PoK or Aksai Chin with labels.

## Map style options

- Default (the "Twins" look): flat top-down satellite, bold flat fills with a white top sheen that grow from the
  centre, white edge + glow, a small lift (scale + shadow) on landing, boxed name labels on pins, big white/gold
  numbers, the restless camera. No 3D relief tilts (the creator rejected them).
- App-style flat map (the reference's "map app" look): draw it from Natural Earth / traced outlines in code (pale
  land, blue water, a red pin). Never screenshot a map app.
- Paper map (`build_greenland_maps.py: paper()`): parchment land with an ink coastline and ripple lines offshore, drawn
  from the same land mask.

## Why plates are painted as backgrounds

`src/<topic>/edit/Map.tsx` paints each plate as the background of a screen-sized box (`backgroundSize` and
`backgroundPosition` place it). On deep zooms an `<img>` blown up thousands of times crashed Chrome after a few
hundred frames; a background only paints what is on screen. Plates are preloaded with `delayRender` + `Image.decode()`
so no frame comes out blank, a coarse plate is skipped once it would be enlarged more than 30× under a covering finer
plate, and fine plates fade in when the camera gets within 9× of their native scale.
