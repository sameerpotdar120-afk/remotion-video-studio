# 10 · Stills, preview, 4K render, delivery, clean-up

## 1. Stills across the timeline (every change)

```bash
cp tools/stills.mjs stills.tmp.mjs                      # run from the project root
rm -rf node_modules/.cache/webpack
B=<headless shell> node stills.tmp.mjs src/<topic>/edit/render.tsx /tmp/pub /tmp/st <Topic>4K60 0 1.8 3.5 6.2 8.5 ...
rm stills.tmp.mjs
```

Pick times on both sides of every transition, every label, the split screen, the inserts and the last frame. Paste
them into contact sheets (PIL, 15 per sheet, the time written on each) and look for: labels cut at the edges or under
the split screen, overlaps, empty or blurry plates, wrong outlines, captions colliding with text, frame 0 vs the last
frame. Fix, render just those again.

## 2. Preview (540p, the creator approves this)

```bash
npx remotion render src/<topic>/edit/render.tsx <Topic>4K60 /tmp/prev.mp4 --public-dir=/tmp/pub \
  --browser-executable=$B --scale=0.5 --concurrency=1 --gl=angle --muted --crf=23
ffmpeg -i /tmp/prev.mp4 -i public/<topic>/audio/mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest \
  -movflags +faststart <topic>_preview.mp4
```

Use **concurrency 1** for map-heavy edits: with 2-4 tabs Chrome crashed ("Page crashed!", a decoder thread trap in
the system log), with one tab the same edit rendered cleanly in ~16 minutes. Check the frame count
(`ffprobe -count_frames`) and a contact sheet of the preview (`fps=1/3,scale=108:-1,tile=9x3`) before sending it.

## 3. 4K 60 fps master on helpers

Branch for the render: `git push origin HEAD:refs/heads/<topic>-render`. Split the frames into equal ranges, one per
helper (the creator says how many; two worked well for an 80 s Short, ~70 minutes in total), and inside each range
render sub-chunks of ~600 frames so a crash only costs one sub-chunk. Each helper gets this prompt (fill S/E):

```
You are a render helper for the "<Title>" Short (Remotion 4). Work autonomously, don't ask questions, don't open PRs,
don't change any source code. Your only output is rendered chunk files pushed to the branch `<topic>-render`.
YOUR FRAMES: S-E, rendered as sub-chunks in order: S-…, …-E.
1. git checkout -B <topic>-render
2. npm ci (no playwright install). B=$(ls -d /opt/pw-browsers/chromium_headless_shell-*/chrome-linux/headless_shell | head -1)
3. mkdir -p /tmp/pub/brand /tmp/pub/<topic> && cp public/brand/Montserrat.ttf public/brand/logo_round_192.png /tmp/pub/brand/
   && cp -r public/<topic>/maps public/<topic>/img public/<topic>/fonts public/<topic>/null /tmp/pub/<topic>/
4. npx remotion bundle src/<topic>/edit/render.tsx --out-dir=/tmp/bundle --public-dir=/tmp/pub --log=error
5. For each sub-chunk S-E, in the BACKGROUND (never a foreground command that can time out), concurrency 1, retry up
   to 3 times on "Page crashed":
   npx remotion render /tmp/bundle <Topic>4K60 /tmp/raw_S.mp4 --frames=S-E --browser-executable=$B --scale=2
     --props='{"audio":""}' --concurrency=1 --gl=angle --codec=h264 --crf=16 --muted --timeout=240000
   ffmpeg -y -i /tmp/raw_S.mp4 -c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p -profile:v high -level 5.2 -g 60
     -threads 4 render_chunks/<topic>/f_SSSSS.mp4   (S zero-padded to 5 digits)
   ffprobe -v error -count_frames -show_entries stream=width,height,r_frame_rate,nb_read_frames -of csv=p=0 <file>
     must print 2160,3840,60/1,E-S+1
   git add <file> && git commit -m "render chunk S-E" && git push origin HEAD:<topic>-render
   (on rejection: git pull --rebase origin <topic>-render and push again, up to 15 times; never force-push)
6. Reply with one line per sub-chunk: file name, size, frame count.
```

Sparse-checkout the helpers to `src`, `public/<topic>`, `public/brand` with depth 1. Check on them every ~30 minutes
(the branch's file list and each helper's status); a helper's background command stops after 2 hours, so keep each
helper's share under ~90 minutes.

## 4. Assemble the master

If the machine doing it has less than ~2 GB free, give this to one more helper (sparse: `public/<topic>/audio`):

```bash
git fetch --depth=1 origin <topic>-render
for f in $(git ls-tree --name-only FETCH_HEAD render_chunks/<topic>/); do git show FETCH_HEAD:$f > /tmp/ch/$(basename $f); done
# check each chunk: 2160x3840, 60/1, frame count = next start - own start; total = durationInFrames
cd /tmp/ch && ls f_*.mp4 | sort | sed "s/^/file /" > list.txt
ffmpeg -f concat -safe 0 -i list.txt -i <repo>/public/<topic>/audio/mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 320k \
  -shortest -movflags +faststart /tmp/<topic>_4k60_master.mp4
git lfs install --local && git lfs track exports/<topic>_4k60_master.mp4
git add --sparse .gitattributes exports/<topic>_4k60_master.mp4 && git commit -m "<topic> 4K60 master" && git push
```

## 5. Verify and deliver

```bash
U=https://github.com/<owner>/<repo>/raw/<branch>/exports/<topic>_4k60_master.mp4
ffprobe -v error -show_entries stream=codec_type,width,height,r_frame_rate:format=duration -of csv=p=0 "$U"
for t in 3.5 10 47 67; do ffmpeg -ss $t -i "$U" -frames:v 1 -vf scale=270:-1 m_$t.jpg; done
```

Give the creator the raw link (it opens in the browser), the size, frame count, length, and what the spot-checks
showed. Close every helper.

## 6. Clean up (after the upload kit is delivered)

Delete the topic's uploads (reference, VO, zips, host clips), scratch files (frames, previews, tile caches, whisper
model), Remotion's temp bundles in /tmp, and hide the finished topic from the working copy with
`git sparse-checkout` (it all stays on GitHub). Keep only what helps the next video: the code in `src/`, the tools, the
house-style docs, fonts, brand and host files.
