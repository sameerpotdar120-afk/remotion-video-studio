# 12 · Troubleshooting (everything that broke, and the fix)

## Rendering

| Symptom | Cause | Fix |
| --- | --- | --- |
| "Page crashed!" after a few hundred frames on deep zooms | a coarse plate drawn as a giant `<img>` (blown up thousands of times) | paint plates as screen-sized backgrounds (`Map.tsx`), skip a coarse plate once it is >30× under a covering finer one |
| "Page crashed!" at frame 0 or early, a `trap int3` in `headless_shell` in the system log | several tabs decoding large plates at once | `--concurrency=1`; split the work across helpers instead of tabs |
| Single stills render but the full render crashes | memory builds up over a long render in one tab | render in ~600-frame sub-chunks, retry a crashed chunk up to 3 times |
| A blank or half-loaded map frame | images not decoded when the frame was captured | preload plates and SVG images with `delayRender` + `Image.decode()` |
| "EncodingError: The source image cannot be decoded" in the log | the browser dropping a decode under memory pressure | usually harmless; check stills around that time; lower concurrency |
| A plate blurry or a blocky blue square on a small lake | the DEM water tint on a close-up, or a plate too coarse | close-up plates without the water tint; pick the satellite zoom for the closest `mpp` |
| Black band at the top or bottom of a frame | the plate does not reach the frame's edge at that zoom | make close-up plates tall enough for 9:16 (formula in 05_maps.md); move the camera |
| Label cut off at the screen edge or under the split screen | target too close to an edge | move the camera target (not the label); flip the label side |
| Text overlapping (a prop over a label, quote over captions) | layout chosen without the stills | render stills at the exact moment, move or shrink one of them |
| Last frame does not match frame 0 | a periodic motion not on `LOOPF`, captions or an overlay still visible at the end | every oscillation on `LOOPF(k)`; hide captions in the first and last 0.3 s; end the camera on `CAM0` |
| Typed Devanagari breaks a matra | splitting by code unit | split by grapheme (`Intl.Segmenter`) |

## Data and tools

| Symptom | Fix |
| --- | --- |
| faster-whisper: `open() got an unexpected keyword argument 'metadata_errors'` | decode with ffmpeg to 16 kHz WAV and pass a numpy array (tools/vo_timing.py does) |
| Whisper merges 10 s into one segment with no word times | use `silencedetect` pauses as phrase boundaries |
| A Natural Earth name lookup fails (`KeyError: 'Quebec'`) | check the exact spelling in the shapefile (`Québec`, `Lake Mistassini`) |
| Lake tracing grabs forest, or leaks along rivers into other lakes | raw-satellite water test; region growing with a tolerance; clip to a box; check the outline on a contact sheet |
| Two lakes trace as the same patch | the published point is off: move the seed onto the right lake (records like "southwest of …") |
| `git add` refuses a path | it is outside the sparse checkout: `git add --sparse <path>` or `git sparse-checkout add <dir>` |
| A pulled branch deletes your working files | the path is outside the sparse checkout; restore with `git show HEAD:<path> > <path>` |

## Machines and helpers

| Symptom | Fix |
| --- | --- |
| "No space left on device" / render refuses on low disk | delete scratch frames, old previews, tile caches, the whisper model, `/tmp/remotion-webpack-bundle-*`, and hide finished topics with sparse checkout; join big files on a helper |
| Git grows by gigabytes from fetched render branches | delete the remote-tracking ref (`git update-ref -d refs/remotes/origin/<branch>`), expire the reflog, `git prune --expire=now` |
| A helper's long render stops after 2 hours | keep each helper's share under ~90 min; for frames that are lost, blend neighbours (Blender plates) or re-render the sub-chunk |
| A helper cannot be created ("repository access check failed") | render that chunk yourself, or retry later |
| The session machine restarts and a local render vanishes | re-run it; push every finished chunk immediately |
| Chrome for HyperFrames / Remotion missing | point to an installed headless shell (`--browser-executable`, or `PRODUCER_HEADLESS_SHELL_PATH` for HyperFrames) |

## Look and taste (the creator's notes)

- "Looks cheap": small props, flat timing, nothing moving. Make subjects big, add secondary motion, follow the
  reference's moves exactly.
- Blender shots that do not match the line are rejected: show exactly what the words say.
- 3D relief tilts were rejected for maps: flat top-down satellite with bold fills.
- Grain is never wanted.
