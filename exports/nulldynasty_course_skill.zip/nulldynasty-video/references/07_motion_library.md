# 07 · Motion components

Every animation the reference shows is built as its own Remotion component, timed from the frame-by-frame analysis,
tested alone, then used in the edit. Rules:

- 60 fps, sized for 1080×1920 (render at `--scale=2`), big by default (they must fill a reel).
- Pure functions of the frame (`useCurrentFrame()` inside a `Sequence`, or `t` passed in). Randomness only from
  `random('seed')`, never `Math.random()`.
- Secondary motion on everything: overshoot pops (springs), idle bob, wobble, shimmer. Nothing is ever still.
- Text-free where possible (words go in the edit); Devanagari typed by grapheme cluster (`Intl.Segmenter`, see
  `darien/anim.ts: graphemes`) so matras never split.
- Test on a plain backdrop composition and look at stills through the whole move before using it.

Optional delivery to the creator: a `motion_assets.md` table (component, reference time, line, what it does, size,
frames) and, if they render them elsewhere, each as a transparent WebM (`--codec=vp9 --pixel-format=yuva420p`).

## The library you already have

### `src/canadalakes/motion/`
| Component | What it does |
| --- | --- |
| QuestionStorm | ~200 "???" labels pop in (6-frame overshoot each), then fly to the centre, shrink and fade |
| ThoughtBubble | two small circles pop 4 frames apart, the cloud springs open, three dots pulse in turn |
| PeopleCrowd | white person icons rise into a crowd 2 frames apart, then bob |
| PinDrop | pin falls, squashes, ring ripples, boxed label slides up |
| WhipCard | a picture card whips in with heavy motion blur, settles tilted, slow push; leaves the same way |
| TypeOn | text types one character every N frames with a caret, two-tone tail |

### `src/ukweather/motion/` (the house-style reference)
| Component | What it does |
| --- | --- |
| U01TouristPop | a character pops onto the map from a dot (overshoot, squash on landing); a furled umbrella swings up and snaps open in 4 frames; slow bob |
| U02WeatherMontage | one full-screen weather per word (rain, fog, sun, hail), each layer starting on its word, the character reacting |
| U03WindBlow | diagonal white wind streaks race across |
| U04NeonSlam | a word slams in huge from the right, rotated −5°, cropped by the frame, shrinks to title size over 20 frames with a red neon glow pulse; drifts; punches up and flies off left |
| U05Lightning | a forked white-blue bolt strikes from the top (bright 3 frames, flicker, fade), full-screen flash, blue glow; deterministic forks from a seed |
| U06FillDevelop | a country flashes cream at full opacity, then develops into its colour |
| U07Calendar | a tear-off calendar flies in and lands tilted; a page flips off every 3 frames (pad wobbling ±8°); the last page shows the number; label types in |
| U08EllipseTitle | a hand-drawn white ellipse draws round a point in 12 frames, a neon-red title types in, a hand-drawn arrow draws from the title |
| U09TiltWorld | the flat world map tilts back in perspective |
| U10GiantWord | a giant word wipes in from the left (cropped by the frame), shifts light blue → white, settles over a gradient band with isobar curves sweeping |
| U11GlowLabel | a glowing cyan label pops on and breathes |
| U12RibbonGrow | tapered ribbons with a lighter ridge line (mountain ranges) grow along paths, staggered 4 frames |
| U13HatchHalo | fat diagonal stripes sweep the frame (6 frames), condense into a hatched blob with a bright rim that contracts onto an area (~18 frames); the land inside greys; a title types in |
| U14DashArrow | a thick dashed, glowing arrow draws along a curve |
| U15FlyAtCamera | a name types in letter by letter, holds, then scales ×14 at the camera in 30 frames (ease-in) as the transition |
| U16WindCurls | moisture rings over the sea and white crescent wind strokes with a curl at the head drift across in layers; raindrop splashes |
| U17AirTag | a rounded tag with a white rim slides in from any side in 12 frames with an overshoot, tilted, then bobs; colour per category |
| U18SendUmbrella | the send-to-a-friend close: a send button pops and pulses, a prop drifts onto it, a paper plane carries it off |
| U99Reel | every component in a row, to check them |

### `src/sikkim/motion/` and friends
| Component | What it does |
| --- | --- |
| S01RailWeb | gold dots light up on junctions, gold lines shoot between them |
| S02StateGlow | one state lights up: everything outside darkens, inside a tint with an inner glow and a bright rim; neighbouring borders draw on thick and white |
| S03Title3D | a bold 3D title: gradient, bevel highlight, deep extrusion |
| S04Track | a drawn railway (rails + sleepers) grows along a path |
| S05Pins | pin drop with a bounce and a ring, a dark label bar types out |
| S06Himalaya | a region turns into illustrated snow-capped mountains |
| S07Slope | a side-view card comparing a gentle and a steep slope |
| S08Hex | hexagon badge windows with a white rim and cyan glow |
| S09Route | a route draws in pink with a bright head, stations pop |
| S10Gauge | a ring gauge sweeps to N % while the number counts |
| S11Storm | dark storm clouds roll in from the top and bottom edges in layers |
| S12Card | a white-framed card slides in from the right, tilted, overshoots and settles, holding a live view with a caption bar; floats while held |
| S13Pulse | red rings throb out from a point (earthquake) |
| S14Portal | an illustrated tunnel portal in a rock face |
| S15FactCard | a dark fact card in our own words (never a screenshot of an article) |
| S16TunnelRush | flying through a tunnel being built |
| S17CloudWipe | clouds billow in from the bottom, cover the frame (the cut point at half time), then part to reveal the next shot: a transition and the loop's return |
| C11PaperTear (`src/chandigarh/motion`) | the shot tears away in four jagged strips peeling off left one after another (white torn edge, shadow), revealing the next |
| Tunnel7Rain (`src/sikkim/tests`) | monsoon rain in three depth layers on a canvas |

## Writing a new one

1. Go frame by frame through the reference move; note start, peak, settle in frames.
2. Express it as a function of `f` (frames) or `t`: springs (`spring({frame, fps, config: {damping, stiffness}})` or
   `pop()`), eased ramps (`ramp(t, a, b, inOut)`), decays (`kick`).
3. Make the defaults big.
4. Add it to a test composition, render stills at its key frames, compare with the reference sheet.
