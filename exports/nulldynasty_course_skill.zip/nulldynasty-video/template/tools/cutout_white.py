"""Cut a cartoon/prop image out of its plain white background: near-white pixels connected to the border are
background (so white parts inside the subject survive), edge eroded 1 px and feathered, cropped to the subject.

    python3 -I tools/cutout_white.py in.png out.png
"""
import sys, numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage
src, dst = sys.argv[1], sys.argv[2]
im = Image.open(src).convert('RGB'); a = np.asarray(im).astype(np.int16)
# near-white pixels connected to the border are background
white = (a.min(axis=2) > 232) & ((a.max(axis=2) - a.min(axis=2)) < 22)
lab, n = ndimage.label(white)
border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
bg = np.isin(lab, list(border))
alpha = (~bg).astype(np.uint8) * 255
al = Image.fromarray(alpha).filter(ImageFilter.MinFilter(3)).filter(ImageFilter.GaussianBlur(1.2))
out = im.convert('RGBA'); out.putalpha(al)
bb = out.getbbox(); out = out.crop(bb)
out.save(dst, optimize=True); print(dst, out.size)
