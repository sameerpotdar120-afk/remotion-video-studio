"""Key a solid #00FF00 screen (a monitor, a map board) out of an image so a map or video can show through it, with
despill. Prints the screen box (x0 y0 x1 y1) in image pixels: use it to place the layer behind.

    python3 -I tools/greenkey.py in.png out.png
"""
import sys, numpy as np
from PIL import Image, ImageFilter
src, dst = sys.argv[1], sys.argv[2]
im = Image.open(src).convert('RGB'); a = np.asarray(im).astype(np.float32)
g = a[..., 1] - np.maximum(a[..., 0], a[..., 2])
alpha = np.clip(1 - (g - 40) / 60, 0, 1)
al = Image.fromarray((alpha * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(0.8))
# despill
a2 = a.copy(); a2[..., 1] = np.minimum(a[..., 1], np.maximum(a[..., 0], a[..., 2]) + 10)
out = Image.fromarray(a2.astype(np.uint8)).convert('RGBA'); out.putalpha(al)
ys, xs = np.where(alpha < 0.5); print(dst, 'screen box', xs.min(), ys.min(), xs.max(), ys.max())
out.save(dst, optimize=True)
