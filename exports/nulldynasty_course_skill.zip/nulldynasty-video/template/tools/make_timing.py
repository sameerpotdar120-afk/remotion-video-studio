"""Build src/<topic>/edit/timing.json: the cue times you picked from the VO, and word-by-word captions spread over
each script line by character length (whisper's Hindi spelling is not good enough to show on screen, so captions
use the creator's own script text).

    python3 tools/make_timing.py cues.json lines.json src/<topic>/edit/timing.json DURATION_S

cues.json  {"bees1": 1.08, ...}             names you use in cam.ts / the edit (one per beat, from words.json)
lines.json [[start, end, "line text"], ...] each script line with its spoken start and end
"""
import json
import sys

cues, lines, out, dur = json.load(open(sys.argv[1])), json.load(open(sys.argv[2], encoding="utf-8")), sys.argv[3], float(sys.argv[4])
caps = []
for a, b, text in lines:
    ws = text.split()
    tot = sum(len(w) + 3 for w in ws)
    t = a
    for w in ws:
        caps.append([round(t, 2), w])
        t += (b - a) * (len(w) + 3) / tot
json.dump({"duration": dur, "cues": cues, "caps": caps}, open(out, "w", encoding="utf-8"), ensure_ascii=False)
print(len(caps), "caption words")
