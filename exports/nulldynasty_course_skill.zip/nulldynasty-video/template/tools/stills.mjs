// Render stills at chosen seconds (quarter size) to check a timeline fast.
//   B=<headless shell> node tools/stills.mjs src/<topic>/edit/render.tsx <publicDir> <outDir> <CompositionId> 0 1.8 3.5 ...
// Put it in the project root before running (Remotion resolves from there) and clear node_modules/.cache/webpack first.
import { bundle } from '@remotion/bundler';
import { renderStill, selectComposition } from '@remotion/renderer';
const [entry, pub, out, comp, ...secs] = process.argv.slice(2);
const serveUrl = await bundle({ entryPoint: entry, publicDir: pub });
const browserExecutable = process.env.B;
const composition = await selectComposition({ serveUrl, id: comp, browserExecutable, chromiumOptions: { gl: 'angle' } });
for (const s of secs) {
  const f = Math.min(composition.durationInFrames - 1, Math.round(Number(s) * composition.fps));
  await renderStill({ composition, serveUrl, output: `${out}/s${String(s).padStart(5, '0')}.jpg`, frame: f, imageFormat: 'jpeg', jpegQuality: 80, scale: 0.25, browserExecutable, timeoutInMilliseconds: 120000, chromiumOptions: { gl: 'angle' } });
}
console.log('ok');
