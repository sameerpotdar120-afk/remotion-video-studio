"""Word timings for the creator's Hindi VO, plus the pauses, so every cue in the edit can sit on a word.

    python3 tools/vo_timing.py public/<topic>/audio/vo.mp3 public/<topic>/script_hindi.txt out_dir/

Writes out_dir/words.json ([{w, s, e}] in seconds) and prints one line per segment, then the pauses (silencedetect).
Uses faster-whisper "small" (multilingual, ~460 MB download the first time; set HF_HUB_CACHE to keep it off a full
disk), language "hi", and the script as the initial prompt so names come out closer to the script. Whisper misspells
Hindi and can merge long stretches into one segment: where a stretch has no word times, use the printed pauses
(phrase boundaries) and your ears. Audio is decoded with ffmpeg to 16 kHz mono and passed as an array (the av package
that faster-whisper uses can fail on newer versions).
"""
import json
import subprocess
import sys
import wave
from pathlib import Path

import numpy as np


def main() -> None:
    vo, script, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
    out.mkdir(parents=True, exist_ok=True)
    wav = out / "vo16k.wav"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(vo), "-ac", "1", "-ar", "16000", str(wav)], check=True)
    w = wave.open(str(wav))
    a = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
    from faster_whisper import WhisperModel  # noqa: PLC0415
    m = WhisperModel("small", device="cpu", compute_type="int8")
    segs, _ = m.transcribe(a, language="hi", word_timestamps=True, initial_prompt=script.read_text(encoding="utf-8")[:600], vad_filter=False)
    words = []
    for s in segs:
        print(f"[{s.start:6.2f}-{s.end:6.2f}] {s.text.strip()}")
        words += [{"w": x.word.strip(), "s": round(x.start, 3), "e": round(x.end, 3)} for x in s.words]
    (out / "words.json").write_text(json.dumps(words, ensure_ascii=False), encoding="utf-8")
    print(" ".join(f"{x['w']}@{x['s']:.2f}" for x in words))
    r = subprocess.run(["ffmpeg", "-v", "info", "-i", str(vo), "-af", "silencedetect=noise=-35dB:d=0.12", "-f", "null", "-"], capture_output=True, text=True)
    pauses = [ln.split("silence_")[1] for ln in r.stderr.splitlines() if "silence_start" in ln or "silence_end" in ln]
    print("pauses:", " | ".join(p.split("|")[0].strip() for p in pauses))


if __name__ == "__main__":
    main()
