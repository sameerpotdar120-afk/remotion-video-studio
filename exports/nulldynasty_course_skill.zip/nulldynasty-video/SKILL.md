---
name: nulldynasty-video
description: Make a NullDynasty-style geography and map-story Short (Hindi or any language, 9:16, 60 fps, 4K) from a reference video, end to end - frame-by-frame reference analysis, script, image and host-clip prompts, VO word timing, free satellite map plates, the Remotion edit (map camera, fills, pins, kinetic labels, cartoon inserts, split-screen host, captions, grade), motion components, optional Blender shots, the sound mix, preview, 4K render on helpers, thumbnail and upload kit. Use whenever someone wants to make, edit, render or publish a video in this style, or asks for any one step of it.
---

# NullDynasty video skill

This skill is the whole production system behind the NullDynasty channel (YouTube @null_dynasty, Instagram
@nulldynasty): Hindi geography and map-story Shorts built in code with Remotion, from free satellite data, with a
masked host in split screen, a playful sound design and a seamless loop ending. Every step below was used on real
videos; the worked examples are in `examples/` and the full working code is in `template/`.

Read this file first, then the reference for the step you are on. Do the steps in order; each one ends in something
the creator approves before the next begins.

## The 12 steps

| # | Step | Output | Read |
| --- | --- | --- | --- |
| 0 | Set up the machine once | Node 22, Remotion, Python libs, ffmpeg, fonts | `references/00_setup.md` |
| 1 | Analyse the reference video frame by frame | `public/<topic>/reference_analysis.md` | `references/01_reference_analysis.md` |
| 2 | Write and polish the script (the creator's wording wins) | `public/<topic>/script_hindi.txt` | `references/02_script.md` |
| 3 | Prompts: images (GPT / Gemini) and host clips (Google Omni) | `asset_prompts.md`, `omni_prompts.md` | `references/03_prompts.md` |
| 4 | Ingest: cut out images, key green screens, crop host clips, time the VO | `public/<topic>/img`, `words.json`, `timing.json` | `references/04_assets_and_vo.md` |
| 5 | Map plates and geo data from free sources | `public/<topic>/maps/*.jpg`, `src/<topic>/geo.json` | `references/05_maps.md` |
| 6 | The edit: camera, layers, fills, pins, labels, inserts, host, captions, grade, loop | `src/<topic>/edit/*` | `references/06_edit.md` |
| 7 | Motion components (every animation the reference has) | `src/<topic>/motion/*` | `references/07_motion_library.md` |
| 8 | Optional: Blender shots of real terrain or props | `public/<topic>/blender/*.mp4` | `references/08_blender.md` |
| 9 | Sound: VO, music bed, SFX on every hit, loop-safe mix | `public/<topic>/audio/mix.wav` | `references/09_sound.md` |
| 10 | Stills check, preview, 4K 60 fps render on helpers | the 4K master via Git LFS | `references/10_render.md` |
| 11 | Thumbnail and upload kit (title, description, tags, pinned comment, captions) | `exports/<topic>_*` | `references/11_upload_kit.md` |
| 12 | Clean up the disk, hide the finished topic | free space for the next video | `references/10_render.md` (last section) |

When something breaks, look in `references/12_troubleshooting.md` first: every crash and dead end we hit is there
with its fix. The rules that never bend (copyright, India's map, AI labels, the host) are in `references/13_rules.md`, and the
house style the creator approved is in `references/house_style.md`.

## The look, in one paragraph

A flat, top-down EOX Sentinel-2 satellite map, graded teal shadows and warm highlights, vignette, darker top and
bottom, never any film grain. A restless camera that breathes, drifts, punches on the big words and whips between
places with motion blur. Every place the voice names lights up as it is said: a bold fill that pops in with a white
sheen and a glowing white edge, a red pin that drops and squashes, a boxed two-tone label (white word, gold word).
Big kinetic words slam in. Cartoon or photo inserts whip in as cards. A masked host appears only in the middle, in
split screen, for 5-8 s in a Short. Small word-by-word captions. A light, playful music bed under the voice, a sound
effect on every visual hit, and an ending that runs straight back into frame 0.

## How the code is laid out (template/)

```
template/
  package.json, tsconfig.json, remotion.config.ts   Remotion 4.0.523, React 19
  src/canadalakes/      THE STARTING TEMPLATE: a complete video (Canada lake names, 79 s)
    edit/cam.ts         camera keys on VO cues, breathe/drift/punch, loop-periodic motion, Mercator helpers
    edit/Map.tsx        plates coarse → fine, painted as screen-sized backgrounds, preloaded
    edit/CanadaLakes.tsx  the whole edit: vectors, overlays, inserts, host split, captions, grade, credits
    edit/Cover.tsx      the thumbnail composition
    edit/render.tsx     render-only entry (compositions <Topic>4K60 and <Topic>Cover)
    edit/font.ts        Google Fonts loader (Anton, Jost, Baloo 2)
    edit/timing.json    cues + caption words
    motion/             QuestionStorm, ThoughtBubble, PeopleCrowd, PinDrop, WhipCard, TypeOn
  src/ukweather/        the house-style reference video (UK weather): 18 motion components, cloud layers, grade
  src/sikkim/           a video with Blender shots, rain, storm, gauges, routes, 3D title, cloud-wipe loop
  src/darien/anim.ts    easing, ramp, pop (spring), kick, window helpers
  src/brand/Watermark.tsx  YOUR logo + handle (put your own files in public/brand)
  tools/                Python: map plates, lake tracing, cut-outs, green key, VO timing, timing.json, mixes,
                        Blender scenes and render helpers, stills script
```

Start a new video by copying `src/canadalakes` to `src/<topic>` and `tools/build_canadalakes_maps.py` /
`tools/mix_canadalakes.py` to the new topic's names, then change the data, cues and scenes. Do not start from a blank
file.

## Working with the creator

- Hand over drafts as proposals; their words win. End every deliverable with a copyable block and ask: ship it, or
  change it?
- Before starting a step that needs their files, list exactly what to send (VO, images, host clips) and check each
  file when it arrives (size, frames, duration).
- Times: when they ask how long, answer in their time zone (for NullDynasty: IST, India Standard Time).
- Never invent a number, a fact, a source or a quote. Check every fact in the script on the web, hedge what is only an
  estimate, and drop what cannot be confirmed.
- Commit and push after every step; a cloud session's disk is temporary.

## What is not in this skill (and why)

- Music and sound effects: Mixkit and Sonniss files may not be redistributed. Download them yourself (free) from
  mixkit.co and the Sonniss GDC bundles; the file names the mixes expect are listed in `references/09_sound.md`.
- Map imagery and data: download them (free) with the tools; EOX tiles are CC BY 4.0 and must be credited on screen.
- NullDynasty's own logo, host character ("Null"), voice and finished videos: they are the channel's brand. Make your
  own host and logo; the prompts in `references/03_prompts.md` show how.
- The `skills_bundled/` folder carries two helper skills (yt-script with its hook scorer, yt-seo) under their MIT
  licence; install them next to this one.
